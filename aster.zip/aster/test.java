import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

class HelloWorld {
    public static void main(String[] args)  {
        
            // creating list of commands  
        List<String> commands = new ArrayList<String>(); 
        commands.add("ls"); // command 
        commands.add("-l"); // command 
        executeCommand(commands);
        // creating the process 
       
    
    }
    public static void executeCommand(List<String> commands){
        try {
            ProcessBuilder pb = new ProcessBuilder(); 

            pb.command(commands);
        // startinf the process 
        Process process = pb.start(); 
        System.out.println(pb.directory()); 

        // for reading the ouput from stream 
        BufferedReader stdInput = new BufferedReader(new
         InputStreamReader(process.getInputStream())); 
        String s = null; 
        while ((s = stdInput.readLine()) != null) 
        { 
            System.out.println(s.split(" ")[s.split(" ").length-1]); 
        } 
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}