import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class main {
    public static void main(final String[] args) {
       
        final ProcessBuilder processBuilder = new ProcessBuilder();
        processBuilder.command("./test.sh");
     
        try {

            final Process process = processBuilder.start();

            final StringBuilder output = new StringBuilder();

            final BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line + "\n");
            }

            final int exitVal = process.waitFor();
            if (exitVal == 0) {
                System.out.println("Success!");
                System.out.println(output.toString());
                // final String[] arrayList = output.toString().split(" ");
                // for (int i = 0; i < arrayList.length; i++) {
                //     final String className = arrayList[i];
                //    System.out.println(className);
                // }
                System.exit(0);
            } else {
                // abnormal...
            }

        } catch (final IOException e) {
            e.printStackTrace();
        } catch (final InterruptedException e) {
            e.printStackTrace();
        }

    }

   
}