#!/usr/bin/env bash
COM=$(git diff-tree --no-commit-id --name-only -r 2703514)
echo $COM