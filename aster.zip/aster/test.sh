#!/usr/bin/env bash
# set -e

PROJECT_ROOT=$(dirname $(cd "$(dirname "$0")"; pwd))
cd ${PROJECT_ROOT}
# mkdir "classes"
# cd "classes"
# ./gradlew assembleDebug
# ./gradlew testDebugUnitTest --tests com.simplemobiletools.calculator.MainActivityTest
jdeps -verbose:class -e 'com.simplemobiletools.*' ${PROJECT_ROOT}/app/build/intermediates/app_classes/debug/classes.jar
# cd "com/simplemobiletools/calculator"
# ALLFILES=$(ls */*)
# echo $ALLFILES
# for i in $(echo $ALLFILES | tr ";" "\n")
# do
#   $F=$(jdeps -verbose:class $i)
#   echo $F
# done
# COM=$(git diff-tree --no-commit-id --name-only -r 2703514)
# echo $COM
# declare -A affectedFileMap
# for i in $(echo $COM | tr ";" "\n")
# do
#   affectedFileMap[$i]=$i
# done
# echo ${affectedFileMap["fastlane/metadata/android/zh-rCN/title.txt"]}  
